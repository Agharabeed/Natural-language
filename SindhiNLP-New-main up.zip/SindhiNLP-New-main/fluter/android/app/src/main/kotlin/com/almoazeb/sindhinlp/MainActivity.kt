package com.almoazeb.sindhinlp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
