import sys
from googletrans import Translator
from pprint import pprint

#initialize the Translator
translator = Translator()

text = sys.argv[1]
source_lan = "en" #English Language
translated_to= "sd" #Sindhi Language

#translate text
translated_text = translator.translate(text, src=source_lan, dest = translated_to)

print(f"'actual': {text}, 'translated': {translated_text.text}, 'pronunciation': {translated_text.pronunciation}, 'data': {translated_text.extra_data}")

