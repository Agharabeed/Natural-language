import sys
import nltk

from nltk.stem import WordNetLemmatizer
wordnet_lemmatizer = WordNetLemmatizer()

word_data = sys.argv[1]

nltk_tokens = nltk.word_tokenize(word_data)
for w in nltk_tokens:
       print ("Actual: " + w," & Lemma: " + wordnet_lemmatizer.lemmatize(w))