# import these modules
import sys
from nltk.stem import PorterStemmer
from nltk.tokenize import word_tokenize

ps = PorterStemmer()

# choose some words to be stemmed
words = sys.argv[1]
#words = ["ملي "," ملڻ "," مليو"," ملندا"," ملندي "," ملنديون "," مليون "," مليا"]

for w in words:
    print(w, " : ", ps.stem(w))