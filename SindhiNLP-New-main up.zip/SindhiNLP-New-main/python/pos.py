import sys
import nltk

word_data = sys.argv[1]
tokens = nltk.word_tokenize(word_data)

print ("Parts of speech: ", nltk.pos_tag(tokens))