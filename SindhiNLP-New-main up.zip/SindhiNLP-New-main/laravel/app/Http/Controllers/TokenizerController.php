<?php

namespace App\Http\Controllers;

use App\Models\Tokenizer;
use Illuminate\Http\Request;

class TokenizerController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Tokenizer  $tokenizer
     * @return \Illuminate\Http\Response
     */
    public function show(Tokenizer $tokenizer)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Tokenizer  $tokenizer
     * @return \Illuminate\Http\Response
     */
    public function edit(Tokenizer $tokenizer)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Tokenizer  $tokenizer
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Tokenizer $tokenizer)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Tokenizer  $tokenizer
     * @return \Illuminate\Http\Response
     */
    public function destroy(Tokenizer $tokenizer)
    {
        //
    }

    public function tokenizer($string)
    {
        $command = escapeshellcmd("python /python/tokenization.py ".$string);
        $output = shell_exec($command);
        Tokenizer::create([
            'data'  => $output,
        ]);

        return $output;
    }
}
