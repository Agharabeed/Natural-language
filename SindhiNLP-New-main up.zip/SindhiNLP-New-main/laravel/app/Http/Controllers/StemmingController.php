<?php

namespace App\Http\Controllers;

use App\Models\Stemming;
use Illuminate\Http\Request;

class StemmingController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Stemming  $stemming
     * @return \Illuminate\Http\Response
     */
    public function show(Stemming $stemming)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\Stemming  $stemming
     * @return \Illuminate\Http\Response
     */
    public function edit(Stemming $stemming)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Stemming  $stemming
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Stemming $stemming)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Stemming  $stemming
     * @return \Illuminate\Http\Response
     */
    public function destroy(Stemming $stemming)
    {
        //
    }
    public function stemming($string)
    {
        $command = escapeshellcmd("python /python/stemming.py ".$string);
        $output = shell_exec($command);
        Stemming::create([
            'data'  => $output,
        ]);

        return $output;
    }
}
