<?php

namespace App\Http\Controllers;

use App\Models\translation;
use Illuminate\Http\Request;

class TranslationController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        //
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\translation  $translation
     * @return \Illuminate\Http\Response
     */
    public function show(translation $translation)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Models\translation  $translation
     * @return \Illuminate\Http\Response
     */
    public function edit(translation $translation)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\translation  $translation
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, translation $translation)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\translation  $translation
     * @return \Illuminate\Http\Response
     */
    public function destroy(translation $translation)
    {
        //
    }

    public function app($string)
    {
        $command = escapeshellcmd("python /python/4587430.py ".$string);
        $output = shell_exec($command);
        Translation::create([
            'data'  => $output,
        ]);

        return $output;
    }
}
